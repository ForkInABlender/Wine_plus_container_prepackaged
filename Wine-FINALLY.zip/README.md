INSTRUCTIONS: <br>
Go to "main.sh" <br>
Look below code <br>
Replace (your app here) with your apps exe. <br>
EXAMPLE: <br>
wine 7z1900.exe <br>
wine OBS.exe <br>
If your exe has a space, put it in quotes: <br>
wine 'Among Us.exe' <br>