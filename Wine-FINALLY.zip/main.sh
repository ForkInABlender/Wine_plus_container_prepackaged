export NIXPKGS_ALLOW_UNFREE=1
#cd /home/runner
wineboot --init

#winetricks dlls
bash -c "~/Wine-FINALLY/virtualgl2.6.5-install/bin/vglrun +ocl +wm +xcb winetricks dlls"